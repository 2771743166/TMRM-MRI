`"CST_H_field.m"` is a program used to plot the results of CST simulations.  
`"LTspice.m"` is a program used to plot the results from LTspice.  
`"SNR_double_FA_20240611_1.m"` is used for processing and plotting the B1 field.  
`"SSH_det_Re_Im_2.m"` is used for calculating the real and imaginary parts of the SSH model.  
`"SSH_freq.m"` is used for calculating the frequency response of the SSH circuit.